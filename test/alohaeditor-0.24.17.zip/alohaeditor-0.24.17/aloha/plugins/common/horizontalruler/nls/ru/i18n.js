define({
	"button.addhr.tooltip": "Добавить горизонтальную линейку"
});
