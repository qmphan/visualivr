define({
	"button.createulist.tooltip": "Unsortierte Liste einfügen",
	"button.createolist.tooltip": "Sortierte Liste einfügen",
	"button.indentlist.tooltip": "Liste einrücken",
	"button.outdentlist.tooltip": "Liste ausrücken",
	"floatingmenu.tab.list": "Listen"
});
