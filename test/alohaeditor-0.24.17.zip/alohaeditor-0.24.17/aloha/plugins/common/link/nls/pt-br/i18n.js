define({
	"button.addlink.tooltip": "Inserir link",
	"button.removelink.tooltip": "Remover link",
	"newlink.defaulttext": "Novo link",
	"floatingmenu.tab.link": "Link",
	"link.target.self": "Auto",
	"link.target.blank": "Em branco",
	"link.target.parent": "Parente",
	"link.target.top": "Topo",
	"link.target.framename": "Nome do frame",
	"link.target.legend": "Alvo",
	"link.title.legend": "Título",
	"insertLink": "Ctrl+K"
});
