define({
	"button.addlink.tooltip": "插入链接",
	"button.removelink.tooltip": "移除链接",
	"newlink.defaulttext": "新链接",
	"floatingmenu.tab.link": "链接",
	"link.target.self": "本页面",
	"link.target.blank": "新页面",
	"link.target.parent": "父页面",
	"link.target.top": "最上层页面",
	"link.target.framename": "框架名",
	"link.target.legend": "目标",
	"link.title.legend": "标题",
	"insertLink": "ctrl+k"
});
