define({
	"button.toggledragdrop.tooltip": "切换拖放功能"
});
