define({
	"floatingmenu.tab.related": "Поврзано",
	"button.zemanta.tooltip": "Zemanta",
	"zemanta.message.shorttext": "За да најде поврзани статии, слики или ознаки, на Zemanta сервисот му требаат повеќе од 140 карактери."
});
