define({
	"button.addimage.tooltip": "Внеси слика",
	"button.removeimage.tooltip": "Одстрани слика",
	"newimage.defaulttext": "Нова слика",
	"floatingmenu.tab.img": "Слика"
});
