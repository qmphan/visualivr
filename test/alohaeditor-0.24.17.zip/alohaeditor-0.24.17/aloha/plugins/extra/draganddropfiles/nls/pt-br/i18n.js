define({
	"floatingmenu.tab.file": "Arquivo"
});
