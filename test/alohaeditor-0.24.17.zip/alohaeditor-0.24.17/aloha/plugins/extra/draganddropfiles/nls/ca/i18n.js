define({
	"floatingmenu.tab.file": "Arxiu"
});
