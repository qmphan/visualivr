define({
	'change-text-color': 'Textfarbe ändern',
	'remove-text-color': 'Textfarbe entfernen'
});
