define({
	root: {
		'change-text-color': 'Change text color',
		'remove-text-color': 'Remove text color'
	},
	de: true
});
