define({
	"floatingmenu.tab.wai-lang": "Comentari d\'idioma",
	"button.add-wai-lang-remove.tooltip": "Suprimeix el comentari d\'idioma",
	"button.add-wai-lang.tooltip": "Afegeix un comentari d\'idioma"
});
