define({
	"button.addlink.tooltip": "Verweis einfügen",
	"button.removelink.tooltip": "Verweis entfernen",
	"newlink.defaulttext": "Neuer Verweis",
	"floatingmenu.tab.link": "Verweis"
});
