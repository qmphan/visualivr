define({
	"button.addlink.tooltip": "Insereix un enllaç",
	"button.removelink.tooltip": "Suprimeix l\'enllaç",
	"newlink.defaulttext": "Enllaç nou",
	"floatingmenu.tab.link": "Enllaç"
});
