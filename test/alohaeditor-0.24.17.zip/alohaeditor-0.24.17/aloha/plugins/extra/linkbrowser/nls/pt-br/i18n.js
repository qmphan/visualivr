define({
	"button.addlink.tooltip": "Inserir link",
	"button.removelink.tooltip": "Remover link",
	"newlink.defaulttext": "Novo link",
	"floatingmenu.tab.link": "Link"
});
