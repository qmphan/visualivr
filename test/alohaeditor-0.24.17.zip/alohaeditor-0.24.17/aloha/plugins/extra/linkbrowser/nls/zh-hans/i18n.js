define({
	"button.addlink.tooltip": "插入链接",
	"button.removelink.tooltip": "移除链接",
	"newlink.defaulttext": "新链接",
	"floatingmenu.tab.link": "链接"
});
