define({
	"cite.button.add.quote": "Formatar seleção como citação",
	"cite.button.add.blockquote": "Formatar seleção como citação de bloco"
});
