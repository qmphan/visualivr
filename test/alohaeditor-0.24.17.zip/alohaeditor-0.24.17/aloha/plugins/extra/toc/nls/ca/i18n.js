define({
	"button.addtoc.tooltip": "Taula de continguts"
});
