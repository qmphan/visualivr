define({
	"button.addtoc.tooltip": "Табела на содржина"
});
