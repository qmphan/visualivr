define({
	"button.formatlessPaste.tooltip": "Habilita/deshabilita l\'enganxada sense format"
});
