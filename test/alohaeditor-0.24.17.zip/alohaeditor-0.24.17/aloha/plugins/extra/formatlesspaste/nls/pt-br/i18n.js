define({
	"button.formatlessPaste.tooltip": "Alternar colar sem formatação"
});
