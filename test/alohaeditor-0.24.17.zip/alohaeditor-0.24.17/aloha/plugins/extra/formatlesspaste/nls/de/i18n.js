define({
	"button.formatlessPaste.tooltip": "Ohne Format einfügen de-/aktivieren"
});
