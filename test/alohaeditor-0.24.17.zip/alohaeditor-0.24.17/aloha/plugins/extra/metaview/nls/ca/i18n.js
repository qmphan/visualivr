define({
	"button.switch-metaview.tooltip": "Canvia entre la visualització «meta» i «normal»"
});
