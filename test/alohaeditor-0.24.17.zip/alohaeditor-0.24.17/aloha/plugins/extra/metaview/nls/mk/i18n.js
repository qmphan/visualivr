define({
	"button.switch-metaview.tooltip": "Промени помеѓу мета и нормален поглед"
});
